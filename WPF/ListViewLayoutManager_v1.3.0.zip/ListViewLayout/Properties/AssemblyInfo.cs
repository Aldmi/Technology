// -- FILE ------------------------------------------------------------------
// name       : AssemblyInfo.cs
// created    : Jani Giannoudis - 2008.04.03
// language   : c#
// environment: .NET 3.0
// copyright  : (c) 2008-2012 by Itenso GmbH, Switzerland
// --------------------------------------------------------------------------
using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle( "ListViewLayout" )]
[assembly: AssemblyDescription( "" )]
[assembly: AssemblyConfiguration( "" )]
[assembly: AssemblyCompany( "Itenso GmbH" )]
[assembly: AssemblyProduct( "ListViewLayout" )]
[assembly: AssemblyCopyright( "Copyright © Itenso GmbH 2008-2012" )]
[assembly: AssemblyTrademark( "" )]
[assembly: AssemblyCulture( "" )]
[assembly: ComVisible( false )]
[assembly: CLSCompliant( true )]
[assembly: ThemeInfo(
		ResourceDictionaryLocation.None, //where theme specific resource dictionaries are located
		ResourceDictionaryLocation.SourceAssembly //where the generic resource dictionary is located
)]
[assembly: AssemblyVersion( "1.3.0.0" )]
[assembly: AssemblyFileVersion( "1.3.0.0" )]

// -- EOF -------------------------------------------------------------------
