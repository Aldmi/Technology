﻿// -- FILE ------------------------------------------------------------------
// name       : App.xaml.cs
// created    : Jani Giannoudis - 2008.03.27
// language   : c#
// environment: .NET 3.0
// copyright  : (c) 2008-2012 by Itenso GmbH, Switzerland
// --------------------------------------------------------------------------

namespace Itenso.Windows.Controls.ListViewLayoutDemo
{

	// ------------------------------------------------------------------------
	public partial class App
	{
	} // class App

} // namespace Itenso.Windows.Controls.ListViewLayoutDemo
// -- EOF -------------------------------------------------------------------
